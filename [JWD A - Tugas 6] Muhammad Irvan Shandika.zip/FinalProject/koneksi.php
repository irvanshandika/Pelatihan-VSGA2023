<?php
$database = 'simperpus_vsga2023';
$username = 'simperpus';
$password = 'z-2+w)e2EA7tRlRX26';
$server = 'sga.domcloud.id';

$koneksi = mysqli_connect($server, $username, $password, $database);


if (!$koneksi) {
  die("Koneksi gagal: " . mysqli_connect_error());
}
