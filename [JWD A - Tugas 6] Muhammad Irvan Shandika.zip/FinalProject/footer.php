<footer>
    <hr>
    <p class="text-center">© 2023 <a href="http://irvanshandika.my.id" class="link-dark link-offset-2 link-underline link-underline-opacity-0">Irvan</a>. All Rights Reserved.</p>
</footer>